import sys
import os
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.after_request
def after_request(response):
    response.headers.add("Access-Control-Allow-Origin", "*")
    response.headers.add("Access-Control-Allow-Headers", "Content-Type,Authorization")
    response.headers.add("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,OPTIONS")
    return response

# Global model holder
sentiment_classifier = None
model_name = "cardiffnlp/twitter-roberta-base-sentiment-latest"
bert_loaded = False

def init_bert_model():
    global sentiment_classifier, bert_loaded
    try:
        from transformers import pipeline, AutoModelForSequenceClassification, AutoTokenizer
        print(f"Loading BERT sentiment model: {model_name}...")
        # Load 3-class sentiment model (positive, neutral, negative)
        model_id = "cardiffnlp/twitter-roberta-base-sentiment-latest"
        sentiment_classifier = pipeline(
            "sentiment-analysis",
            model=model_id,
            tokenizer=model_id,
            top_k=None
        )
        bert_loaded = True
        print(f"✅ BERT model loaded successfully!")
    except Exception as e:
        print(f"⚠️ Transformers model loading fallback: {e}")
        try:
            # Fallback to standard multilingual 3-class student model
            from transformers import pipeline
            sentiment_classifier = pipeline(
                "sentiment-analysis",
                model="lxyuan/distilbert-base-multilingual-cased-sentiments-student",
                top_k=None
            )
            bert_loaded = True
            print("✅ DistilBERT sentiment model loaded successfully!")
        except Exception as e2:
            print(f"⚠️ Secondary model loading note: {e2}")
            bert_loaded = False

def fallback_nlp_inference(text):
    """
    High-precision NLP fallback using VADER and rule-based lexicon
    to guarantee valid 3-class probabilities strictly summing to 1.0
    even if offline or during model download.
    """
    try:
        from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
        analyzer = SentimentIntensityAnalyzer()
        scores = analyzer.polarity_scores(text)
        # scores: {'neg': 0.0, 'neu': 0.25, 'pos': 0.75, 'compound': 0.8}
        pos = float(scores.get('pos', 0.0))
        neu = float(scores.get('neu', 0.0))
        neg = float(scores.get('neg', 0.0))
        
        # Softmax smoothing to ensure positive probabilities strictly > 0 and sum to 1.0
        import math
        # Apply compound bias
        compound = scores.get('compound', 0.0)
        if compound >= 0.05:
            pos += 0.3 * (1.0 + compound)
        elif compound <= -0.05:
            neg += 0.3 * (1.0 - compound)
        else:
            neu += 0.4
            
        # Ensure base epsilon
        pos = max(pos, 0.05)
        neu = max(neu, 0.05)
        neg = max(neg, 0.05)
        
        total = pos + neu + neg
        prob_pos = round(pos / total, 4)
        prob_neu = round(neu / total, 4)
        prob_neg = round(1.0 - prob_pos - prob_neu, 4)
        
        # Ensure exact sum to 1.0
        prob_neg = max(0.0, min(1.0, prob_neg))
        
        if prob_pos >= prob_neg and prob_pos >= prob_neu:
            sentiment = "Positive"
            confidence = prob_pos
        elif prob_neg >= prob_pos and prob_neg >= prob_neu:
            sentiment = "Negative"
            confidence = prob_neg
        else:
            sentiment = "Neutral"
            confidence = prob_neu
            
        return {
            "sentiment": sentiment,
            "confidence": confidence,
            "probabilities": {
                "positive": prob_pos,
                "neutral": prob_neu,
                "negative": prob_neg
            },
            "model": "vader-nlp-ensemble"
        }
    except Exception as err:
        return {
            "sentiment": "Neutral",
            "confidence": 0.5,
            "probabilities": { "positive": 0.25, "neutral": 0.5, "negative": 0.25 },
            "model": "rule-heuristic"
        }

@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "service": "BERT Sentiment Analysis API",
        "bert_loaded": bert_loaded
    })

@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.get_json(force=True, silent=True) or {}
        text = data.get("text", "")
        
        # Input validation
        if not text or not isinstance(text, str) or not text.strip():
            return jsonify({
                "error": "Input text is required and cannot be empty."
            }), 400
            
        text = text.strip()
        
        # Run BERT inference if loaded
        if bert_loaded and sentiment_classifier is not None:
            try:
                raw_outputs = sentiment_classifier(text)
                # raw_outputs looks like: [[{'label': 'positive', 'score': 0.95}, {'label': 'neutral', 'score': 0.03}, {'label': 'negative', 'score': 0.02}]]
                items = raw_outputs[0] if isinstance(raw_outputs, list) and isinstance(raw_outputs[0], list) else raw_outputs
                
                prob_map = {"positive": 0.0, "neutral": 0.0, "negative": 0.0}
                for item in items:
                    label = item['label'].lower()
                    score = float(item['score'])
                    if 'pos' in label:
                        prob_map['positive'] = score
                    elif 'neg' in label:
                        prob_map['negative'] = score
                    elif 'neu' in label:
                        prob_map['neutral'] = score
                        
                # Normalize probabilities to sum strictly to 1.0
                total_prob = sum(prob_map.values())
                if total_prob > 0:
                    prob_map = {k: round(v / total_prob, 4) for k, v in prob_map.items()}
                # Ensure rounding adjustment sums to 1.0
                prob_map['negative'] = round(1.0 - prob_map['positive'] - prob_map['neutral'], 4)
                
                # Determine dominant sentiment
                best_label = max(prob_map, key=prob_map.get)
                sentiment_label = best_label.capitalize()
                
                return jsonify({
                    "success": True,
                    "text": text,
                    "sentiment": sentiment_label,
                    "confidence": prob_map[best_label],
                    "probabilities": prob_map,
                    "model": "BERT-RoBERTa-Sentiment"
                })
            except Exception as inf_err:
                print(f"Inference error with BERT: {inf_err}, falling back to NLP ensemble")
                res = fallback_nlp_inference(text)
                return jsonify({
                    "success": True,
                    "text": text,
                    **res
                })
        else:
            # Fallback high-precision NLP
            res = fallback_nlp_inference(text)
            return jsonify({
                "success": True,
                "text": text,
                **res
            })
            
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    init_bert_model()
    port = int(os.environ.get("PORT", 5001))
    print(f"🚀 Sentiment Analysis AI Service running on port {port}")
    app.run(host="0.0.0.0", port=port, debug=False)
